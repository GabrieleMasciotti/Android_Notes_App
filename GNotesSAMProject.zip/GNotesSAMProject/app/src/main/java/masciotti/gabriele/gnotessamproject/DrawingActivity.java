package masciotti.gabriele.gnotessamproject;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewTreeObserver;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.google.android.material.slider.RangeSlider;

import java.io.ByteArrayOutputStream;

import petrov.kristiyan.colorpicker.ColorPicker;

public class DrawingActivity extends AppCompatActivity {
    private NoteDrawingView painting;
    private RangeSlider rangeSlider;
    private final NotesDataBase notesDataBase = new NotesDataBase(this,"notesDataBase",null,1);
    private int noteID;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.drawer_layout);
        this.painting = (NoteDrawingView) findViewById(R.id.drawing_view);
        this.rangeSlider = (RangeSlider) findViewById(R.id.rangebar);
        Toolbar toolbar = (Toolbar) findViewById(R.id.drawingToolbar);
        setSupportActionBar(toolbar);
        toolbar.setSubtitle(getString(R.string.draw_toolbar_subtitle));
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        noteID = getIntent().getIntExtra("ID_NOTE",-1);
        if(savedInstanceState != null){
            painting.setPaths(savedInstanceState.getParcelableArrayList("PATHS"));
            painting.setColor(savedInstanceState.getInt("COLOR"));
            painting.setWidth(savedInstanceState.getInt("WIDTH"));
        }

        ViewTreeObserver observer = painting.getViewTreeObserver();
        observer.addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
            @Override
            public void onGlobalLayout() {
                painting.getViewTreeObserver().removeOnGlobalLayoutListener(this);
                int width = painting.getMeasuredWidth();
                int height = painting.getMeasuredHeight();
                painting.initBitmapCanvas(height,width);
            }
        });
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putParcelableArrayList("PATHS",painting.getPaths());
        outState.putInt("COLOR",painting.getColor());
        outState.putInt("WIDTH",painting.getStrokeWidth());
    }

    @Override
    public boolean onCreateOptionsMenu(Menu m){
        super.onCreateOptionsMenu(m);
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.drawing_menu,m);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == android.R.id.home) {
            finish();
            return true;
        }
        else{
            if(id == R.id.undo){
                painting.undo();
                return true;
            }
            else{
                if(id == R.id.save_drawing){
                    ByteArrayOutputStream conversionStream = new ByteArrayOutputStream();
                    Bitmap b = painting.getBitmap();
                    b.compress(Bitmap.CompressFormat.JPEG, 100,conversionStream);
                    int id_d = (int) notesDataBase.addImage(conversionStream.toByteArray(), (int) noteID);
                    Intent data = new Intent();
                    data.putExtra("DRAWING_ID",id_d);
                    setResult(RESULT_OK,data);
                    finish();
                    return true;
                }
                else{
                    if(id == R.id.change_pen){
                        ColorPicker colorPicker = new ColorPicker(this);
                        colorPicker.setOnFastChooseColorListener(new ColorPicker.OnFastChooseColorListener() {
                            @Override
                            public void setOnFastChooseColorListener(int position, int color) {
                                painting.setColor(color);
                            }

                            @Override
                            public void onCancel() {
                                colorPicker.dismissDialog();
                            }
                        }).setColumns(5)
                                .setDefaultColorButton(Color.BLACK)
                                .setColors(Color.BLACK,Color.GRAY,Color.BLUE,Color.GREEN,Color.RED,Color.YELLOW,
                                        Color.WHITE,Color.CYAN,Color.LTGRAY,Color.MAGENTA,Color.parseColor("#ffa500"),
                                        Color.parseColor("#8a2be2"),Color.parseColor("#800000"),Color.parseColor("#6495ed"),
                                        Color.parseColor("#b8860b"),Color.parseColor("#006400"),Color.parseColor("#ffb6c1"),
                                        Color.parseColor("#d2691e"),Color.parseColor("#e6e6fa"),Color.parseColor("#a0522d"))
                                .setTitle(getString(R.string.choose_color))
                                .show();
                        rangeSlider.setValueFrom(0.0f);
                        rangeSlider.setValueTo(100.0f);
                        rangeSlider.setVisibility(View.VISIBLE);
                        rangeSlider.addOnChangeListener(new RangeSlider.OnChangeListener() {
                            @Override
                            public void onValueChange(@NonNull RangeSlider slider, float value, boolean fromUser) {
                                painting.setWidth((int) value);
                            }
                        });
                        rangeSlider.addOnSliderTouchListener(new RangeSlider.OnSliderTouchListener() {
                            @Override
                            public void onStartTrackingTouch(@NonNull RangeSlider slider) {}

                            @Override
                            public void onStopTrackingTouch(@NonNull RangeSlider slider) {
                                rangeSlider.setVisibility(View.GONE);
                            }
                        });
                        return true;
                    }
                    else{
                        return false;
                    }
                }
            }
        }
    }

}
