package masciotti.gabriele.gnotessamproject;

import android.Manifest;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteBlobTooBigException;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.Spannable;
import android.text.SpannableStringBuilder;
import android.text.style.ImageSpan;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.exifinterface.media.ExifInterface;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

public class note_details_activity extends AppCompatActivity {

    private EditText title;
    private EditText text;
    private String titleBeforeEdit;
    private String textBeforeEdit;
    private boolean typingMode = false;
    private boolean creatingNewNote = false;
    private long noteID = -1;
    private Toolbar toolbar;
    private final NotesDataBase notesDataBase = new NotesDataBase(this,"notesDataBase",null,1);
    private String noteText;
    private final String imagePlaceholder = "imgPlaceholder%";         //stringa utilizzata per individuare le immagini inserite all'interno delle note
    private final Activity thiss = (Activity) this;
    private loadNoteDetail loadingTask = null;
    private ArrayList<String> imgsIDS = new ArrayList<>();
    private boolean screenRotationFlag = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_note_details);
        toolbar = (Toolbar) findViewById(R.id.detailToolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setLogo(R.mipmap.ic_launcher);
        getSupportActionBar().setDisplayUseLogoEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        Intent intent = getIntent();
        String name = intent.getStringExtra("NOTE_NAME");
        noteText = intent.getStringExtra("NOTE_TEXT");
        if(savedInstanceState != null){                             //ripristino dello stato dell'activity
            title = (EditText) findViewById(R.id.title_detail);
            text = (EditText) findViewById(R.id.text_detail);
            title.setText(savedInstanceState.getString("NAME"));
            text.setText(savedInstanceState.getString("TEXT"));
            toolbar.setSubtitle(savedInstanceState.getString("NAME"));
            noteID = savedInstanceState.getLong("ID");
            titleBeforeEdit = savedInstanceState.getString("TITLE_BEFORE_EDIT");
            textBeforeEdit = savedInstanceState.getString("TEXT_BEFORE_EDIT");
            imgsIDS = savedInstanceState.getStringArrayList("IMS_IDS");
            if(!imgsIDS.isEmpty()){
                loadNoteDetail load = new loadNoteDetail();
                load.execute();
            }
            if(savedInstanceState.getBoolean("ON_TYPING")) typingMode = true;
            else{
                typingMode = false;
                title.setEnabled(false);
                text.setEnabled(false);
            }
            if(savedInstanceState.getBoolean("ON_CREATING")) creatingNewNote = true;
            screenRotationFlag = false;
        }
        else{                                               //è la prima volta che l'activity viene creata
            if(name != null && noteText != null){
                toolbar.setSubtitle(name);
                title = (EditText) findViewById(R.id.title_detail);
                text = (EditText) findViewById(R.id.text_detail);
                noteID = Integer.parseInt(getIntent().getStringExtra("NOTE_ID"));
                title.setText(name);
                if(!noteText.contains(imagePlaceholder)){       //la nota non contiene immagini
                    text.setText(noteText);
                }
                else{
                    loadingTask = new loadNoteDetail();         //fa partire il task di caricamento della nota con tutte le immagini
                    loadingTask.execute();
                }
                title.setEnabled(false);
                text.setEnabled(false);
            }
            else {                              //si sta creando una nuova nota
                typingMode = true;
                creatingNewNote = true;
                title = (EditText) findViewById(R.id.title_detail);
                text = (EditText) findViewById(R.id.text_detail);
                title.requestFocus();
            }
        }
    }

    //task asincrono che gestisce il caricamento delle immagini presenti nella nota al momento dell'apertura
    private final class loadNoteDetail extends AsyncTask<Void,Void,String>{
        private SpannableStringBuilder builder;
        private ProgressDialog loadingDialog;
        public loadNoteDetail(){
            super();
        }
        @Override
        protected void onPreExecute(){
            loadingDialog = new ProgressDialog(thiss);
            loadingDialog.setTitle(R.string.loading_note);
            loadingDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
            loadingDialog.show();
        }

        @Override
        protected String doInBackground(Void ...par) {
            int id;
            String pH;
            byte[] arr;
            Cursor cur;
            String originalText = noteText;
            builder = new SpannableStringBuilder(originalText);
            while(noteText.contains(imagePlaceholder)){
                noteText = noteText.substring(noteText.indexOf(imagePlaceholder));
                noteText = noteText.substring(noteText.indexOf("%")+1);
                id = Integer.parseInt(noteText.substring(0,noteText.indexOf("%")));     //id dell'immagine nel database
                pH = imagePlaceholder+id+"%";
                cur = notesDataBase.getImageBitmap(id);
                cur.moveToFirst();
                if(cur.getCount() > 0){
                    if(cur.getInt(1) == noteID){
                        arr = cur.getBlob(0);
                        builder.setSpan(new ImageSpan(null, BitmapFactory.decodeByteArray(arr,0, arr.length)), originalText.indexOf(pH), originalText.indexOf(pH)+pH.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
                        imgsIDS.add(String.valueOf(id));
                    }
                }
                cur.close();
            }
            return "DONE";
        }

        @Override
        protected void onPostExecute(String s){
            text.setText(builder);
            loadingDialog.dismiss();
        }
    }

    private final class loadImageTask extends AsyncTask<Void,Void,String>{
        private ProgressDialog loadingDialog;
        private final Uri selectedImage;
        private boolean done;
        private boolean tryDownload = false;
        private boolean resized = false;
        private int id;
        private Bitmap bitmap;
        private Cursor cur;
        private Bitmap resizedBitmap;
        public loadImageTask(Uri image){
            super();
            this.selectedImage = image;
        }
        @Override
        protected void onPreExecute(){
            loadingDialog = new ProgressDialog(thiss);
            loadingDialog.setTitle(R.string.loading_image);
            loadingDialog.setMessage(getString(R.string.loading_image_message));
            loadingDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
            loadingDialog.show();
        }

        @Override
        protected String doInBackground(Void ...par) {
            if(ContextCompat.checkSelfPermission(thiss,Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED){
                ActivityCompat.requestPermissions(thiss,new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},0);
            }
            int qualityOfLoadedImage = 100;
            boolean possibleLoading = false;
            try {
                bitmap = MediaStore.Images.Media.getBitmap(thiss.getContentResolver(), selectedImage);
                ByteArrayOutputStream conversionStream = new ByteArrayOutputStream();
                bitmap.compress(Bitmap.CompressFormat.JPEG, qualityOfLoadedImage,conversionStream);
                id = (int) notesDataBase.addImage(conversionStream.toByteArray(), (int) noteID);
                cur = notesDataBase.getImageBitmap(id);
                String[] projection = { MediaStore.Images.Media.DATA };
                Cursor cursor = thiss.getContentResolver().query(selectedImage, projection, null, null, null);
                int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
                cursor.moveToFirst();
                ExifInterface ex = new ExifInterface(cursor.getString(column_index));
                String rotation = ex.getAttribute(ExifInterface.TAG_ORIENTATION);
                cursor.close();
                try{
                    possibleLoading = cur.moveToFirst();            //*** se questa istruzione lancia l'eccezione vedere sotto
                    if(!possibleLoading){                           //immagine troppo grande; riduzione della qualità
                        cur.close();
                        notesDataBase.deleteImage(id);
                        conversionStream.reset();
                        int newFatWidth = 2048;                //riduzione della risoluzione
                        int newFatHeight = 1536;
                        Matrix matrix;
                        float scaleWidth ;
                        float scaleHeight;
                        int height = bitmap.getHeight();
                        int width = bitmap.getWidth();
                        matrix = new Matrix();
                        scaleWidth = ((float) newFatWidth) / width;
                        scaleHeight = ((float) newFatHeight) / height;
                        matrix.postScale(scaleWidth, scaleHeight);
                        if(rotation != null){
                            if(Integer.parseInt(rotation) == ExifInterface.ORIENTATION_ROTATE_90) matrix.postRotate(90);
                            if(Integer.parseInt(rotation) == ExifInterface.ORIENTATION_ROTATE_180) matrix.postRotate(180);
                            if(Integer.parseInt(rotation) == ExifInterface.ORIENTATION_ROTATE_270) matrix.postRotate(270);
                        }
                        resizedBitmap = Bitmap.createBitmap(bitmap,0,0,width,height,matrix,true);
                        resizedBitmap.compress(Bitmap.CompressFormat.JPEG, qualityOfLoadedImage,conversionStream);
                        id = (int) notesDataBase.addImage(conversionStream.toByteArray(), (int) noteID);
                        cur = notesDataBase.getImageBitmap(id);
                        possibleLoading = cur.moveToFirst();
                        while(qualityOfLoadedImage > 0 && !possibleLoading){
                            notesDataBase.deleteImage(id);
                            cur.close();
                            conversionStream.reset();
                            qualityOfLoadedImage = qualityOfLoadedImage - 20;               //riduzione della qualità nella compressione
                            resizedBitmap.compress(Bitmap.CompressFormat.JPEG, qualityOfLoadedImage,conversionStream);
                            id = (int) notesDataBase.addImage(conversionStream.toByteArray(), (int) noteID);
                            cur = notesDataBase.getImageBitmap(id);
                            possibleLoading = cur.moveToFirst();
                        }
                        if(possibleLoading){
                            resized = true;
                            done = true;
                        }
                        else{           //caricamento dell'immagine
                            resized = true;
                            done = false;
                        }
                    }
                    else{           //caricamento dell'immagine
                        done = true;
                    }
                }
                catch (SQLiteBlobTooBigException e){        //*** se moveToFirst lancia l'eccezione si segue un procedimento di carimento differente
                    cur.close();
                    notesDataBase.deleteImage(id);
                    conversionStream.reset();
                    int newWidth = 2048;                //riduzione della risoluzione
                    int newHeight = 1536;
                    Matrix matrix;
                    float scaleWidth ;
                    float scaleHeight;
                    int height = bitmap.getHeight();
                    int width = bitmap.getWidth();
                    matrix = new Matrix();
                    scaleWidth = ((float) newWidth) / width;
                    scaleHeight = ((float) newHeight) / height;
                    matrix.postScale(scaleWidth, scaleHeight);
                    if(rotation != null){
                        if(Integer.parseInt(rotation) == ExifInterface.ORIENTATION_ROTATE_90) matrix.postRotate(90);
                        if(Integer.parseInt(rotation) == ExifInterface.ORIENTATION_ROTATE_180) matrix.postRotate(180);
                        if(Integer.parseInt(rotation) == ExifInterface.ORIENTATION_ROTATE_270) matrix.postRotate(270);
                    }
                    resizedBitmap = Bitmap.createBitmap(bitmap,0,0,width,height,matrix,true);
                    resizedBitmap.compress(Bitmap.CompressFormat.JPEG, qualityOfLoadedImage,conversionStream);
                    id = (int) notesDataBase.addImage(conversionStream.toByteArray(), (int) noteID);
                    cur = notesDataBase.getImageBitmap(id);
                    while(qualityOfLoadedImage > 0 && !possibleLoading){
                        try{
                            possibleLoading = cur.moveToFirst();
                        }
                        catch (SQLiteBlobTooBigException exe){
                            notesDataBase.deleteImage(id);
                            cur.close();
                            conversionStream.reset();
                            qualityOfLoadedImage = qualityOfLoadedImage - 20;               //riduzione della qualità nella compressione
                            resizedBitmap.compress(Bitmap.CompressFormat.JPEG, qualityOfLoadedImage,conversionStream);
                            id = (int) notesDataBase.addImage(conversionStream.toByteArray(), (int) noteID);
                            cur = notesDataBase.getImageBitmap(id);
                        }
                    }
                    if(possibleLoading){
                        resized = true;
                        done = true;
                    }
                    else{           //caricamento dell'immagine
                        resized = true;
                        done = false;
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
            catch (IllegalArgumentException | NullPointerException e){
                done = false;
                tryDownload = true;
            }
            return "DONE";
        }

        @Override
        protected void onPostExecute(String s){
            if(done){
                int selectionCursor = text.getSelectionStart();
                String pH = imagePlaceholder+id+"%";
                imgsIDS.add(String.valueOf(id));
                text.getText().insert(selectionCursor, pH);
                selectionCursor = text.getSelectionStart();
                SpannableStringBuilder builder = new SpannableStringBuilder(text.getText());
                if(!resized) builder.setSpan(new ImageSpan(null, bitmap), selectionCursor - pH.length(), selectionCursor, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
                if(resized) builder.setSpan(new ImageSpan(null, resizedBitmap), selectionCursor - pH.length(), selectionCursor, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
                text.setText(builder);
                text.setSelection(selectionCursor);
                cur.close();
            }
            else {
                if (!tryDownload) Toast.makeText(thiss, R.string.err_loading_image, Toast.LENGTH_LONG).show();
                else Toast.makeText(thiss,R.string.err_loading_image_try_download,Toast.LENGTH_LONG).show();
            }
            loadingDialog.dismiss();
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putBoolean("ON_TYPING", this.typingMode);
        outState.putString("NAME",title.getText().toString());
        outState.putString("TEXT",text.getText().toString());
        outState.putBoolean("ON_CREATING",this.creatingNewNote);
        outState.putLong("ID",this.noteID);
        outState.putString("TITLE_BEFORE_EDIT",titleBeforeEdit);
        outState.putString("TEXT_BEFORE_EDIT",textBeforeEdit);
        outState.putStringArrayList("IMS_IDS",imgsIDS);
        this.screenRotationFlag = true;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu m){
        super.onCreateOptionsMenu(m);
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.note_details_menu,m);
        return true;
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu m){
        super.onPrepareOptionsMenu(m);
        if(typingMode){
            m.findItem(R.id.edit_note).setVisible(false);
            m.findItem(R.id.share_note).setVisible(false);
            m.findItem(R.id.delete_note).setVisible(false);
            m.findItem(R.id.save_note).setVisible(true);
            m.findItem(R.id.add_image_on_note).setVisible(true);
            m.findItem(R.id.add_drawing_on_note).setVisible(true);
            return true;
        }
        else{
            m.findItem(R.id.edit_note).setVisible(true);
            m.findItem(R.id.share_note).setVisible(true);
            m.findItem(R.id.delete_note).setVisible(true);
            m.findItem(R.id.save_note).setVisible(false);
            m.findItem(R.id.add_image_on_note).setVisible(false);
            m.findItem(R.id.add_drawing_on_note).setVisible(false);
            return true;
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == android.R.id.home) {
            finish();
            return true;
        }
        else{
            if(id == R.id.edit_note){
                typingMode = true;
                title.setEnabled(true);
                text.setEnabled(true);
                title.requestFocus();
                titleBeforeEdit = title.getText().toString();
                textBeforeEdit = text.getText().toString();
                invalidateOptionsMenu();
                return true;
            }
            else{
                if(id == R.id.share_note){
                    if(imgsIDS.isEmpty()){
                        Intent sendIntent = new Intent();
                        sendIntent.setAction(Intent.ACTION_SEND);
                        String s = text.getText().toString();
                        sendIntent.putExtra(Intent.EXTRA_TEXT, s);      //testo da condividere
                        sendIntent.setType("text/plain");
                        Intent shareIntent = Intent.createChooser(sendIntent, null);
                        startActivity(shareIntent);
                    }
                    else{
                        sharingNoteWithImages share = new sharingNoteWithImages();
                        share.execute();
                    }
                    return true;
                }
                else{
                    if(id == R.id.delete_note){
                        AlertDialog alertDialog = new AlertDialog.Builder(this).create();
                        alertDialog.setTitle(getString(R.string.dialog_title));
                        alertDialog.setMessage(getString(R.string.dialog_single_text_first)+" ''"+title.getText().toString()+"'' "+getString(R.string.dialog_single_text_second));
                        alertDialog.setButton(AlertDialog.BUTTON_POSITIVE,getString(R.string.dialog_pos_but),
                                new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        cleanDatabaseFromDeletedImages cleanTask = new cleanDatabaseFromDeletedImages(imgsIDS,"",notesDataBase);
                                        cleanTask.execute();
                                        notesDataBase.deleteNote((int) noteID);               //elimina la nota
                                        dialog.dismiss();
                                        finish();
                                    }
                                });
                        alertDialog.setButton(AlertDialog.BUTTON_NEGATIVE, getString(R.string.dialog_neg_but), new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                            }
                        });
                        alertDialog.show();
                        return true;
                    }
                    else{
                        if(id == R.id.save_note){
                            if(title.getText().toString().isEmpty() && text.getText().toString().isEmpty()){
                                Toast.makeText(this,R.string.empty_note,Toast.LENGTH_LONG).show();
                                return false;
                            }
                            else{
                                title.setEnabled(false);
                                text.setEnabled(false);
                                typingMode = false;
                                invalidateOptionsMenu();
                                toolbar.setSubtitle(title.getText().toString());
                                if(creatingNewNote){
                                    creatingNewNote = false;
                                    this.noteID = notesDataBase.createNewNote(title.getText().toString(),text.getText().toString());
                                    savingNoteWithImages save = new savingNoteWithImages();
                                    save.execute();
                                }
                                else{
                                    notesDataBase.editNote((int) this.noteID,title.getText().toString(),text.getText().toString());
                                }
                                cleanDatabaseFromDeletedImages cleanTask = new cleanDatabaseFromDeletedImages(imgsIDS,text.getText().toString(),notesDataBase);
                                cleanTask.execute();
                                return true;
                            }
                        }
                        else{
                            if(id == R.id.add_image_on_note){
                                Intent i = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                                thiss.startActivityForResult(i,101);
                                return true;
                            }
                            else{
                                if(id == R.id.add_drawing_on_note){
                                    Intent intentt = new Intent(this,DrawingActivity.class);
                                    intentt.putExtra("ID_NOTE",(int) noteID);
                                    thiss.startActivityForResult(intentt,201);
                                    return true;
                                }
                                else{
                                    return super.onOptionsItemSelected(item);
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == 101){                                                     //caricamento immagine nella nota
            if(resultCode != Activity.RESULT_OK){
                Toast.makeText(this,R.string.err_loading_image,Toast.LENGTH_LONG).show();
            }
            else{
                Uri selectedImage = data.getData();
                loadImageTask task = new loadImageTask(selectedImage);
                task.execute();
            }
        }
        else{                                                                       //caricamento nella nota del disegno salvato dall'utente
            if(resultCode != Activity.RESULT_OK){
                Toast.makeText(this,R.string.err_loading_drawing,Toast.LENGTH_LONG).show();
            }
            else{
                int dr_id = data.getIntExtra("DRAWING_ID",-1);
                int selectionCursor = text.getSelectionStart();
                String pH = imagePlaceholder+dr_id+"%";
                text.getText().insert(selectionCursor, pH);
                selectionCursor = text.getSelectionStart();
                SpannableStringBuilder builder = new SpannableStringBuilder(text.getText());
                Cursor cur = notesDataBase.getImageBitmap(dr_id);
                cur.moveToFirst();
                if(cur.getCount() > 0){
                    if(cur.getInt(1) == noteID){
                        byte[] arr = cur.getBlob(0);
                        builder.setSpan(new ImageSpan(null, BitmapFactory.decodeByteArray(arr,0, arr.length)), selectionCursor - pH.length(), selectionCursor, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
                        imgsIDS.add(String.valueOf(dr_id));
                    }
                }
                text.setSelection(selectionCursor);
                text.setText(builder);
                cur.close();
            }
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        notesDataBase.close();
        if(loadingTask != null){
            loadingTask.cancel(true);
        }
        if(!screenRotationFlag){        //se l'activity non deve essere ridisegnata perché l'utente ha semplicemente ruotato lo schermo
            //rimozione delle immagini inserite prima di uscire senza salvare
            if(creatingNewNote){
                cleanDatabaseFromDeletedImages cleanTask = new cleanDatabaseFromDeletedImages(imgsIDS,"",notesDataBase);
                cleanTask.execute();
            }
            else{
                if(typingMode){
                    cleanDatabaseFromDeletedImages cleanTask = new cleanDatabaseFromDeletedImages(imgsIDS,textBeforeEdit,notesDataBase);
                    cleanTask.execute();
                }
            }
        }
    }

    public static final class cleanDatabaseFromDeletedImages extends AsyncTask<Void,Void,String>{         //task di pulizia del database dalle immagini eliminate
        private ArrayList<String> imgsIDS = null;
        private String notetext;
        private final NotesDataBase notesDataBase;
        private int noteID;
        public cleanDatabaseFromDeletedImages(ArrayList<String> arr,String text,NotesDataBase db){
            super();
            this.imgsIDS = arr;
            this.notetext = text;
            this.notesDataBase = db;
        }

        public cleanDatabaseFromDeletedImages(String text, NotesDataBase db, int idNote){      //elimina tutte le immagini che erano contenute in una nota eliminata dalla home page (con la action bar contestuale)
            super();
            this.notetext = text;
            this.notesDataBase = db;
            this.noteID = idNote;
        }

        @Override
        protected String doInBackground(Void ...par) {
            String imagePlaceholder = "imgPlaceholder%";
            if(imgsIDS != null){
                for(String id : imgsIDS){
                    if(!notetext.contains(imagePlaceholder+id+"%")) {
                        notesDataBase.deleteImage(Integer.parseInt(id));
                    }
                }
            }
            else{
                int id;
                while(notetext.contains(imagePlaceholder)){
                    notetext = notetext.substring(notetext.indexOf(imagePlaceholder));
                    notetext = notetext.substring(notetext.indexOf("%")+1);
                    id = Integer.parseInt(notetext.substring(0,notetext.indexOf("%")));     //id dell'immagine nel database
                    if(notesDataBase.checkRights(noteID,id)) notesDataBase.deleteImage(id);
                }
            }
            return "DONE";
        }
    }

    private final class savingNoteWithImages extends AsyncTask<Void,Void,String>{       //task asincrono di salvataggio di una nuova nota in cui sono state inserite immagini
        private ProgressDialog loadingDialog;
        public savingNoteWithImages(){
            super();
        }
        @Override
        protected void onPreExecute(){
            loadingDialog = new ProgressDialog(thiss);
            loadingDialog.setTitle(R.string.saving_note);
            loadingDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
            loadingDialog.show();
        }

        @Override
        protected String doInBackground(Void ...par) {
            for(String i : imgsIDS){
                notesDataBase.updateImageNoteID((int) noteID,Integer.parseInt(i));      //le immagini della nuova nota (che inizialmente sono memorizzate con indice di nota -1) vengono aggiornate con il nuovo indice della nota
            }
            return "DONE";
        }

        @Override
        protected void onPostExecute(String s){
            loadingDialog.dismiss();
        }
    }

    private final class sharingNoteWithImages extends AsyncTask<Void,Void,String>{      //task rapido di preparazione del contenuto della nota con immagini da condividere
        private ProgressDialog loadingDialog;
        private boolean impossible = false;
        public sharingNoteWithImages(){
            super();
        }
        @Override
        protected void onPreExecute(){
            loadingDialog = new ProgressDialog(thiss);
            loadingDialog.setTitle(R.string.sharing_note_with_images);
            loadingDialog.setMessage(getString(R.string.sharing_message));
            loadingDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
            loadingDialog.show();
        }

        @Override
        protected String doInBackground(Void ...par) {
            Intent sendIntent = new Intent();
            sendIntent.setAction(Intent.ACTION_SEND_MULTIPLE);
            ArrayList<Uri> uris = new ArrayList<>();
            File sharedImageFolder = new File(getCacheDir(),"sharedImages");
            Uri uri = null;
            int autoIncrementName = 0;
            String s = text.getText().toString();
            //preparazione testo della nota da condividere (pulizia dai placeholder delle immagini e dei disegni)
            String original = s;
            String nextLoop = s;
            String toBeRemoved;
            while(original.contains(imagePlaceholder)){
                toBeRemoved = original.substring(original.indexOf(imagePlaceholder),original.indexOf(imagePlaceholder)+imagePlaceholder.length());
                original = original.substring(original.indexOf(imagePlaceholder)+imagePlaceholder.length());
                toBeRemoved = toBeRemoved+original.substring(0,original.indexOf("%"))+"%";
                original = original.substring(original.indexOf("%")+1);
                s = s.replace(toBeRemoved,"");
            }

            sendIntent.putExtra(Intent.EXTRA_TEXT, s);      //testo da condividere

            try {
                //preparazione delle immagini e dei disegni alla condivisione
                boolean t = sharedImageFolder.mkdirs();
                while (nextLoop.contains(imagePlaceholder)) {
                    nextLoop = nextLoop.substring(nextLoop.indexOf(imagePlaceholder) + imagePlaceholder.length());
                    int id_img = Integer.parseInt(nextLoop.substring(0, nextLoop.indexOf("%")));
                    autoIncrementName = autoIncrementName+1;
                    File file = new File(sharedImageFolder, autoIncrementName+".jpeg");
                    FileOutputStream stream = new FileOutputStream(file);
                    Cursor cur = notesDataBase.getImageBitmap(id_img);
                    if(cur.getCount() > 0) {
                        cur.moveToFirst();
                        if (cur.getInt(1) == noteID) {
                            stream.write(cur.getBlob(0));
                            stream.flush();
                            stream.close();
                            uri = FileProvider.getUriForFile(thiss,"masciotti.gabriele.gnotessamproject.fileprovider",file);
                            uris.add(uri);
                        }
                    }
                    cur.close();
                    nextLoop = nextLoop.substring(nextLoop.indexOf("%") + 1);
                }
            }
            catch (IOException e){
                impossible = true;
            }
            sendIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            sendIntent.putParcelableArrayListExtra(Intent.EXTRA_STREAM,uris);
            sendIntent.setType("image/*");
            Intent shareIntent = Intent.createChooser(sendIntent, null);
            startActivity(shareIntent);
            return "DONE";
        }

        @Override
        protected void onPostExecute(String s){
            loadingDialog.dismiss();
            if(impossible) Toast.makeText(thiss,R.string.not_sharing_imgs,Toast.LENGTH_LONG).show();
        }
    }

}