package masciotti.gabriele.gnotessamproject;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.view.ActionMode;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class NotesAdapter extends RecyclerView.Adapter<NotesAdapter.NotesViewHolder> implements View.OnClickListener, View.OnLongClickListener {

    private Cursor cursor = null;
    private final NotesDataBase db;
    private final ArrayList<Integer> selected_notes = new ArrayList<>();

    private final Activity activityMain;

    private ActionMode menuCab;
    private final ActionMode.Callback cab = new ActionMode.Callback() {
        @Override
        public boolean onCreateActionMode(ActionMode mode, Menu menu) {
            MenuInflater inflater = mode.getMenuInflater();
            inflater.inflate(R.menu.cab,menu);
            return true;
        }

        @Override
        public boolean onPrepareActionMode(ActionMode mode, Menu menu) {
            return false;
        }

        @Override
        public boolean onActionItemClicked(ActionMode mode, MenuItem item) {
            AlertDialog alertDialog = new AlertDialog.Builder(activityMain).create();
            alertDialog.setTitle(activityMain.getString(R.string.dialog_title));
            alertDialog.setMessage(activityMain.getString(R.string.dialog_text));
            alertDialog.setButton(AlertDialog.BUTTON_POSITIVE,activityMain.getString(R.string.dialog_pos_but),
                    new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            note_details_activity.cleanDatabaseFromDeletedImages cleanImageTask;
                            for(Integer i : selected_notes){
                                Cursor cur = db.getNote(i);
                                cur.moveToFirst();
                                String text = cur.getString(0);
                                db.deleteNote(i);               //elimina tutte le note selezionate
                                cleanImageTask = new note_details_activity.cleanDatabaseFromDeletedImages(text,db,i);
                                cleanImageTask.execute();
                            }
                            selected_notes.clear();
                            setNewCursor();
                            mode.finish();
                            dialog.dismiss();
                        }
                    });
            alertDialog.setButton(AlertDialog.BUTTON_NEGATIVE, activityMain.getString(R.string.dialog_neg_but), new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    dialog.dismiss();
                    mode.finish();
                }
            });
            alertDialog.show();
            return true;
        }

        @Override
        public void onDestroyActionMode(ActionMode mode) {
            selected_notes.clear();
            notifyDataSetChanged();
            menuCab = null;
        }
    };

    public NotesAdapter(Activity act, NotesDataBase db){
        this.db = db;
        this.activityMain = act;
        this.setNewCursor();
    }

    public void setNewCursor(){
        if(this.cursor != null) {
            cursor.close();
            this.cursor = this.db.getNotesList();
            notifyDataSetChanged();
        }
        else{
            this.cursor = this.db.getNotesList();
        }
    }

    @Override
    public NotesAdapter.NotesViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.card_view_layout,parent,false);
        view.setOnClickListener(this);
        view.setOnLongClickListener(this);
        return new NotesViewHolder(view);
    }

    @Override
    public void onBindViewHolder(NotesViewHolder holder, int position) {
        cursor.moveToPosition(position);
        holder.noteID.setText(cursor.getString(0));         //chiave primaria della nota nel database
        holder.notePos.setText(String.valueOf(cursor.getPosition()));         //posizione della nota all'interno della tabella del cursor (poi utilizzata per recuperare tutto il testo della nota)
        holder.noteName.setText(cursor.getString(1));
        String text = cursor.getString(2);
        String x = text;
        while(x.contains("imgPlaceholder%")){
            x = x.substring(x.indexOf("imgPlaceholder%"));
            x = x.substring(x.indexOf("%")+1);
            int id = Integer.parseInt(x.substring(0,x.indexOf("%")));
            String pH = "imgPlaceholder%"+id+"%";
            text = text.replace(pH,"<IMMAGINE>");
        }
        if(text.length()>102){
            String aux = text.substring(0,101)+"  ...";
            holder.noteText.setText(aux);
        }
        else {
            holder.noteText.setText(text);
        }
        if(selected_notes.contains(Integer.parseInt(cursor.getString(0)))){
            holder.card.setCardBackgroundColor(ContextCompat.getColor(holder.card.getContext(),R.color.card_view_selected));
        }
        else{
            holder.card.setCardBackgroundColor(ContextCompat.getColor(holder.card.getContext(),R.color.card_view_background));
        }
    }

    @Override
    public int getItemCount() {
        return cursor.getCount();
    }

    @Override
    public void onAttachedToRecyclerView(RecyclerView recyclerView) {
        super.onAttachedToRecyclerView(recyclerView);
    }

    @Override
    public void onClick(View v) {
        TextView id = (TextView) v.findViewById(R.id.note_id);
        int n = Integer.parseInt(id.getText().toString());
        TextView na = (TextView) v.findViewById(R.id.note_name);
        String name = na.getText().toString();
        CardView card = (CardView) v.findViewById(R.id.card);
        if(selected_notes.contains(n)) {
            selected_notes.remove(Integer.valueOf(n));
            if(selected_notes.size()==0){
                menuCab.finish();
            }
            else{
                menuCab.setTitle(String.valueOf(selected_notes.size()));
            }
            card.setCardBackgroundColor(ContextCompat.getColor(v.getContext(),R.color.card_view_background));
        }
        else{
            if(menuCab != null){
                card.setCardBackgroundColor(ContextCompat.getColor(v.getContext(),R.color.card_view_selected));
                selected_notes.add(n);
                menuCab.setTitle(String.valueOf(selected_notes.size()));
            }
            else{
                Intent intent =  new Intent(v.getContext(), note_details_activity.class);
                intent.putExtra("NOTE_NAME",name);
                TextView pos = (TextView) v.findViewById(R.id.note_pos);
                cursor.moveToPosition(Integer.parseInt(pos.getText().toString()));
                intent.putExtra("NOTE_TEXT",cursor.getString(2));       //recupera e mostra il testo completo della nota
                intent.putExtra("NOTE_ID",cursor.getString(0));
                activityMain.startActivity(intent);         //si apre l'activity con i dettagli della nota
            }
        }
    }

    @Override
    public boolean onLongClick(View v) {
        TextView id = (TextView) v.findViewById(R.id.note_id);
        int n = Integer.parseInt(id.getText().toString());
        CardView card = (CardView) v.findViewById(R.id.card);
        if(selected_notes.contains(n)){
            selected_notes.remove(Integer.valueOf(n));
            if(selected_notes.size() == 0) menuCab.finish();
            else menuCab.setTitle(String.valueOf(selected_notes.size()));
            card.setCardBackgroundColor(ContextCompat.getColor(v.getContext(),R.color.card_view_background));
        }
        else{
            if(menuCab != null){
                card.setCardBackgroundColor(ContextCompat.getColor(v.getContext(),R.color.card_view_selected));
                selected_notes.add(n);
                menuCab.setTitle(String.valueOf(selected_notes.size()));
            }
            else{
                card.setCardBackgroundColor(ContextCompat.getColor(v.getContext(),R.color.card_view_selected));
                selected_notes.add(n);
                menuCab = activityMain.startActionMode(cab);
                menuCab.setTitle(String.valueOf(selected_notes.size()));
            }
        }
        return true;
    }

    public static class NotesViewHolder extends RecyclerView.ViewHolder{
        CardView card;
        TextView noteID;
        TextView notePos;
        TextView noteName;
        TextView noteText;

        public NotesViewHolder(View noteView){
            super(noteView);
            card = (CardView) noteView.findViewById(R.id.card);
            noteID = (TextView) noteView.findViewById(R.id.note_id);
            notePos = (TextView)  noteView.findViewById(R.id.note_pos);
            noteName = (TextView) noteView.findViewById(R.id.note_name);
            noteText = (TextView) noteView.findViewById(R.id.note_text);

        }
    }


}
