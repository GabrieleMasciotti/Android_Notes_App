package masciotti.gabriele.gnotessamproject;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;

public class NoteDrawingView extends View {

    private Paint paint;
    private Bitmap bitmap;
    private int currentColor = -1;
    private int strokeWidth = -1;
    private ArrayList<Stroke> paths = new ArrayList<>();
    private final Paint mBitmapPaint = new Paint(Paint.DITHER_FLAG);

    private static final float TOUCH_TOLERANCE = 4;
    private float X, Y;
    private Path path;


    public NoteDrawingView(Context context) {
        super(context,null);
    }
    public NoteDrawingView(Context cx, AttributeSet attrs){
        super(cx,attrs);
        paint = new Paint();
        paint.setAntiAlias(true);
        paint.setDither(true);
        paint.setColor(Color.BLACK);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeJoin(Paint.Join.ROUND);
        paint.setStrokeCap(Paint.Cap.ROUND);
        paint.setAlpha(0xff);
        setDrawingCacheEnabled(true);
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec){
        setMeasuredDimension(
                getDefaultSize(getSuggestedMinimumWidth(), widthMeasureSpec),
                getDefaultSize(getSuggestedMinimumHeight(), heightMeasureSpec));
    }

    public void initBitmapCanvas(int height, int width){
        bitmap = Bitmap.createBitmap(width,height,Bitmap.Config.ARGB_8888);
        if(this.currentColor == -1) currentColor = Color.BLACK;
        if(this.strokeWidth == -1) strokeWidth = 20;
    }

    public void undo(){
        if(paths.size() != 0){
            paths.remove(paths.size()-1);   //annulla l'ultima modifica
            invalidate();
        }
    }

    public Bitmap getBitmap(){
        return getDrawingCache();
    }

    public void setColor(int color){
        currentColor = color;
    }

    public void setWidth(int width){
        strokeWidth = width;
    }

    public void setPaths(ArrayList<Stroke> ps){
        this.paths = ps;
    }

    public int getColor(){
        return this.currentColor;
    }

    public int getStrokeWidth(){
        return this.strokeWidth;
    }

    public ArrayList<Stroke> getPaths(){
        return this.paths;
    }

    //disegna i vari path tracciati dall'utente sul canvas che poi finisce nella bitmap
    @Override
    protected void onDraw(Canvas canvas){
        canvas.save();
        int backgroudColor = Color.WHITE;
        canvas.drawColor(backgroudColor);
        for(Stroke str : paths){
            paint.setColor(str.color);
            paint.setStrokeWidth(str.strokeWidth);
            canvas.drawPath(str.path,paint);
        }
        canvas.drawBitmap(bitmap,0,0,mBitmapPaint);
        canvas.restore();
    }

    private void touchStart(float x, float y){      //l'utente poggia il dito sullo schermo per cominciare a disegnare
        path = new Path();
        Stroke str = new Stroke(currentColor,strokeWidth,path);
        paths.add(str);
        path.reset();
        path.moveTo(x,y);
        X = x;
        Y = y;
    }

    private void touchMove(float x, float y){       //l'utente muove il dito sullo schermo per disegnare
        float dx = Math.abs(x - X);
        float dy = Math.abs(y - Y);
        if(dx >= TOUCH_TOLERANCE || dy >=TOUCH_TOLERANCE){
            path.quadTo(X,Y,(x+X)/2,(y+Y)/2);
            X = x;
            Y = y;
        }
    }

    private void touchEnd(){
        path.lineTo(X,Y);           //termina di disegnare la linea creata dall'utente prima che togliesse il dito dallo schermo
    }

    @Override
    public boolean onTouchEvent(MotionEvent event){
        float x = event.getX();
        float y = event.getY();
        switch (event.getAction()){
            case MotionEvent.ACTION_DOWN:           //l'utente poggia il dito sullo schermo
                touchStart(x,y);
                invalidate();
                break;
            case MotionEvent.ACTION_MOVE:           //muove il dito sullo schermo
                touchMove(x,y);
                invalidate();
                break;
            case MotionEvent.ACTION_UP:             //toglie il dito dallo schermo
                touchEnd();
                invalidate();
                break;
        }
        return true;
    }
}
