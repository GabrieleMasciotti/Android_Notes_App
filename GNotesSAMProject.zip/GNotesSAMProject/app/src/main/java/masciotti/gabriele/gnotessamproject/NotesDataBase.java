package masciotti.gabriele.gnotessamproject;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class NotesDataBase extends SQLiteOpenHelper {

    public NotesDataBase(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String creazioneTabella = "CREATE TABLE NotesTable (_ID INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, NOTE_TITLE TEXT, NOTE_TEXT TEXT)";
        db.execSQL(creazioneTabella);
        String tabellaImmagini = "CREATE TABLE ImageTable (_ID INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, IMAGE BLOB, NOTE_ID INTEGER)";
        db.execSQL(tabellaImmagini);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {      //nella pratica mai chiamato
        db.execSQL("DROP TABLE IF EXISTS NotesTable");
        onCreate(db);
    }

    public long createNewNote(String title, String text){
        ContentValues cv = new ContentValues();
        cv.put("NOTE_TITLE",title);
        cv.put("NOTE_TEXT",text);
        return this.getWritableDatabase().insert("NotesTable",null,cv);
    }

    public void editNote(int id, String newtitle, String newtext){
        ContentValues cv = new ContentValues();
        cv.put("NOTE_TITLE",newtitle);
        cv.put("NOTE_TEXT",newtext);
        this.getWritableDatabase().update("NotesTable",cv,"_ID=?",new String[]{String.valueOf(id)});
    }

    public void deleteNote(int id){
        this.getWritableDatabase().delete("NotesTable","_ID=?",new String[]{String.valueOf(id)});
    }

    public Cursor getNotesList(){
        return this.getReadableDatabase().query(false,"NotesTable",new String[]{"_ID","NOTE_TITLE","NOTE_TEXT"},null,null,null,null,null,null);
    }

    public Cursor getNote(int id){
        return this.getReadableDatabase().query(false,"NotesTable",new String[]{"NOTE_TEXT"},"_ID = ?",new String[]{String.valueOf(id)},null,null,null,null);
    }

    public long addImage(byte[] img_Converted,int id_note){
        ContentValues cv = new ContentValues();
        cv.put("IMAGE",img_Converted);
        cv.put("NOTE_ID",id_note);
        return this.getWritableDatabase().insert("ImageTable",null,cv);
    }

    public void updateImageNoteID(int id,int imageId){
        ContentValues cv = new ContentValues();
        cv.put("NOTE_ID",id);
        this.getWritableDatabase().update("ImageTable",cv,"_ID=?",new String[]{String.valueOf(imageId)});
    }

    public boolean checkRights(int noteID, int imageID){
        Cursor cur = this.getReadableDatabase().query(false,"ImageTable",new String[]{"NOTE_ID"}, "_ID=?", new String[]{String.valueOf(noteID)},null,null,null,null);
        cur.moveToFirst();
        if(cur.getCount() == 0){
            cur.close();
            return false;
        }
        else{
            boolean res = imageID == cur.getInt(0);
            cur.close();
            return res;
        }
    }

    public void deleteImage(int id){
        this.getWritableDatabase().delete("ImageTable","_ID=?",new String[]{String.valueOf(id)});
    }

    public Cursor getImageBitmap(int id){
        return this.getReadableDatabase().query(false,"ImageTable",new String[]{"IMAGE","NOTE_ID"}, "_ID=?", new String[]{String.valueOf(id)},null,null,null,null);
    }
}
