package masciotti.gabriele.gnotessamproject;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.appcompat.widget.TooltipCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;


public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private NotesDataBase notesDataBase;
    private NotesAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        RecyclerView recy = (RecyclerView) findViewById(R.id.recy);
        LinearLayoutManager linearLayout = new LinearLayoutManager(this);
        recy.setLayoutManager(linearLayout);
        notesDataBase = new NotesDataBase(this,"notesDataBase",null,1);
        adapter = new NotesAdapter(this, notesDataBase);
        recy.setAdapter(adapter);
        //setting action toolbar
        Toolbar toolbar = (Toolbar) findViewById(R.id.mainToolbar);
        setSupportActionBar(toolbar);
        toolbar.setSubtitle(R.string.app_bar_subtitle);
        getSupportActionBar().setLogo(R.mipmap.ic_launcher);
        getSupportActionBar().setDisplayUseLogoEnabled(true);
        //setting floating action button
        FloatingActionButton floatingActionButton = (FloatingActionButton) findViewById(R.id.fab);
        TooltipCompat.setTooltipText(floatingActionButton,getString(R.string.new_note));
        floatingActionButton.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {       //l'utente vuole creare una nuova nota
        Intent newNoteIntent = new Intent(this,note_details_activity.class);
        startActivity(newNoteIntent);
    }

    //aggiorna la lista delle note dopo che l'utente torna dall'activity di creazione
    @Override
    public void onResume() {
        super.onResume();
        this.adapter.setNewCursor();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        notesDataBase.close();
    }

}